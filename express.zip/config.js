module.exports = {
    mongodb: "",
    port:3001,
    limitRecord:100,
    tokenCoinmarketcap: '359c9f97-b711-417b-bbf3-625311e382f4',
    telegram_token: '',
    domain: '',
    host: ''
}